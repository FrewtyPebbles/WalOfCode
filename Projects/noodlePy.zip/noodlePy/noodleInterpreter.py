from hashlib import new
import sys
import keyWordParser as KWP

#CREATED BY WILLIAM L
# VER 1.0.0

file = open(sys.argv[1] + ".pasta", 'r')
charStream = ""
charSegmentStream = ""
quoting = False
segmentType = ""
entireFile = file.read()
#print(entireFile)
lines = entireFile.split("\n")
fileNoNewLines = ""
for i in lines:
    fileNoNewLines += i.lstrip(" ")
#print(fileNoNewLines)
newentireFile = fileNoNewLines
scopes = []
executing = True

#SCOPE CLASS
class scope:
    def __init__(self, _parentScope = "", _statement = "", _start = 0, _end = len(newentireFile), _canExecute = True):
        self.start = _start
        self.end = _end
        self.parentScope = _parentScope
        self.canExecute = _canExecute
        self.statement = _statement

currentScope = scope("", "", 0,len(newentireFile), True)
for c in range(0, len(newentireFile)):
    #streams
    if c >= currentScope.start and c <= currentScope.end:
        if currentScope.canExecute == True:
            if newentireFile[c] == '"':
                quoting = not quoting
                if quoting == False:
                    charSegmentStream += charStream
                else:
                    continue
            elif quoting == False:
                if newentireFile[c].isspace():
                    charSegmentStream += charStream + " "
                    charStream = ""
                elif newentireFile[c] == "=":
                    segmentType = "set"
                    charStream += newentireFile[c]
                    charSegmentStream += charStream
                    charStream = ""
                elif newentireFile[c] == "^":
                    scopes.append(scope(currentScope, "condition", currentScope.start, currentScope.end))
                    currentScope = scopes[len(scopes)-1]
                elif newentireFile[c] == "?":
                    charSegmentStream += charStream
                    charStream = ""
                    if currentScope.start == currentScope.parentScope.start:
                        currentScope.start = c
                        if currentScope.statement == "condition":
                            condition = charSegmentStream.split()
                            currentScope.canExecute = KWP.conditional(condition[0],condition[1],condition[2])
                    elif currentScope.start != currentScope.parentScope.start:
                        currentScope.end = c
                        currentScope = currentScope.parentScope
                    charSegmentStream = ""
                elif newentireFile[c] == "|":
                    #print(charSegmentStream)
                    if segmentType == "set":
                        #charSegmentStream += charStream
                        LRSIDE = charSegmentStream
                        LRSIDE = LRSIDE.split("=")
                        LRSIDE[0] = LRSIDE[0].strip(" ")
                        LRSIDE[1] = LRSIDE[1].strip(" ")
                        #print(LRSIDE)
                        KWP.equalSet(LRSIDE[0], LRSIDE[1])
                    elif segmentType == "":
                        #print(charSegmentStream)
                        KWP.parse(charSegmentStream)
                    charSegmentStream = ""
                    charStream = ""
                    segmentType = ""
                    quoting = False
                else:
                    charStream += newentireFile[c]
                    charSegmentStream += charStream
                    charStream = ""
            else:#QUOTING
                charStream += newentireFile[c]
        else:
            if newentireFile[c] == "?":
                currentScope = currentScope.parentScope
#print(KWP.VARS())

file.close()