from __future__ import unicode_literals
from curses.ascii import isdigit
from re import A
import sys

### noodlePy By William L.
###  VER 3.1.0

#TODO: MAKE A FUNCTION TO RETURN THE VALUE OF A VARIABLE AFTER PARSEING WHAT TYPE
# IT IS ( LITERAL, VARIABLE, OR VARIABLE LIST / ARRAY ) AND GIVING IT A NEGATIVE
# IF IT NEEDS ONE AND REPLACE TESTS IN THE METHODS by ADDING SINGLE CONDITION
# UTILIZING THE NEW FUNCTIONS TO RETURN THE VALUE OF THE LHS AND RHS. THE FUNCTION 
# WILL RECURSION ITSELF IF AN ARRAY INDEX ALSO HOLDS A VARIABLE UNTILL IT REACHES 
# A LITERAL.


charStream = ""
charSegmentStream = ""
quoting = False
segmentType = ""
scopes = []
sVars = []
openedFiles = []
##FILE READ
file = open(sys.argv[1] + ".pasta", 'r')
entireFile = file.read()
#print(entireFile)
lines = entireFile.split("\n")
fileNoNewLines = ""
for i in lines:
    fileNoNewLines += i.lstrip()
#print(fileNoNewLines)
unicodeLines = fileNoNewLines
newentireFile = unicodeLines

#SCOPE CLASS
class scope:
    def __init__(self, _parentScope = "", _statement = "", _start = 0, _end = len(newentireFile), _canExecute = True):
        self.start = _start
        self.end = _end
        self.parentScope = _parentScope
        self.canExecute = _canExecute
        self.statement = _statement


currentScope = scope(scope("", "global", 0,len(newentireFile), True), "global", 0,len(newentireFile), True)

def isfloat(num):
    try:
        float(num)
        return True
    except ValueError:
        return False

##########KEY WORD PARSER


def VARS(_VARNAME = "all"):
    global scopes
    global charStream
    global charSegmentStream
    global quoting
    global segmentType
    global currentScope
    global sVars
    global keywords
    global methods
    if _VARNAME == "all":
        return sVars
    else:
        #code
        for i in range(len(sVars)):
            if sVars[i][0] == _VARNAME:
                return i
        return False

def newVar(_VAR):
    global scopes
    global charStream
    global charSegmentStream
    global quoting
    global segmentType
    global currentScope
    global sVars
    global keywords
    global methods
    if "`" in _VAR[1]:
        index = _VAR[1].split("`")
        sVars.append([index[0]])
        for i in range(2, 2 + int(index[1])):
            sVars[len(sVars)-1].append("")
    else:
        sVars.append([_VAR[1] , _VAR[2]])

def delVar(_VAR):
    global scopes
    global charStream
    global charSegmentStream
    global quoting
    global segmentType
    global currentScope
    global sVars
    global keywords
    global methods
    for q in range(0, len(sVars)):
        if sVars[q][0] == _VAR:
            sVars.pop(q)
            break

#VAR PARSE FUNCTION:  Returns the value
def varParser(_TextData):
    global scopes
    global charStream
    global charSegmentStream
    global quoting
    global segmentType
    global currentScope
    global sVars
    global keywords
    global methods
    negative = 1
    if "`" in  _TextData:
        index = _TextData.split("`")
        #print(index[0])
        #print(index[1])
        if "`" in  index[1]:
            signedValue = sVars[VARS(index[0])][1 + int(float(varParser(index[1])))]
            if "-" in signedValue:
                negative = -1
            if signedValue.isdigit() or isfloat(signedValue):
                return negative*float(signedValue.strip("-"))
            else:
                return signedValue
        elif VARS(index[1]) is not False:
            signedValue = sVars[VARS(index[0])][1 + int(float(varParser(index[1])))]
            if "-" in signedValue:
                negative = -1
            if signedValue.isdigit() or isfloat(signedValue):
                return negative*float(signedValue.strip("-"))
            else:
                return signedValue
        else:
            signedValue = sVars[VARS(index[0])][1 + int(float(index[1]))]
            if "-" in signedValue:
                negative = -1
                return negative*int(signedValue.strip("-"))
            if signedValue.isdigit() or isfloat(signedValue):
                return negative*float(signedValue.strip("-"))
            else:
                return signedValue
    elif VARS(_TextData) is not False:
        signedValue = sVars[VARS(_TextData)][1]
        if "-" in signedValue:
            negative = -1
        if signedValue.isdigit() or isfloat(signedValue):
            return negative*float(signedValue.strip("-"))
        else:
            return signedValue
    else:
        signedValue = _TextData
        if "-" in signedValue:
            negative = -1
        if signedValue.isdigit() or isfloat(signedValue):
            return negative*float(signedValue.strip("-"))
        else:
            return signedValue



def equalSet(_LHS, _RHS):
    global scopes
    global charStream
    global charSegmentStream
    global quoting
    global segmentType
    global currentScope
    global sVars
    global keywords
    global methods
    _LHS.strip()
    _RHS.strip()
    #print("LHS = " + str(varParser(_LHS)))
    #print("RHS = " + str(varParser(_RHS)))
    if "`" in  _LHS:
        index = _LHS.split("`")
        sVars[VARS(index[0])][1 + int(varParser(index[1]))] = str(varParser(_RHS))
    if VARS(_LHS) is not False:
        sVars[VARS(_LHS)][1] = str(varParser(_RHS))

def addSet(_LHS, _RHS):
    global scopes
    global charStream
    global charSegmentStream
    global quoting
    global segmentType
    global currentScope
    global sVars
    global keywords
    global methods
    _LHS.strip()
    _RHS.strip()
    if "`" in  _LHS:
        index = _LHS.split("`")
        sVars[VARS(index[0])][1 + int(float(varParser(index[1])))] = str(varParser(_LHS) + varParser(_RHS))
    if VARS(_LHS) is not False:
        sVars[VARS(_LHS)][1] = str(varParser(_LHS) + varParser(_RHS))

def subtractSet(_LHS, _RHS):
    global scopes
    global charStream
    global charSegmentStream
    global quoting
    global segmentType
    global currentScope
    global sVars
    global keywords
    global methods
    _LHS.strip()
    _RHS.strip()
    if "`" in  _LHS:
        index = _LHS.split("`")
        sVars[VARS(index[0])][1 + int(float(varParser(index[1])))] = str(varParser(_LHS) - varParser(_RHS))
    if VARS(_LHS) is not False:
        sVars[VARS(_LHS)][1] = str(varParser(_LHS) - varParser(_RHS))
    
def multiplySet(_LHS, _RHS):
    global scopes
    global charStream
    global charSegmentStream
    global quoting
    global segmentType
    global currentScope
    global sVars
    global keywords
    global methods
    _LHS.strip()
    _RHS.strip()
    if "`" in  _LHS:
        index = _LHS.split("`")
        sVars[VARS(index[0])][1 + int(float(varParser(index[1])))] = str(varParser(_LHS) * varParser(_RHS))
    if VARS(_LHS) is not False:
        sVars[VARS(_LHS)][1] = str(varParser(_LHS) * varParser(_RHS))

def divideSet(_LHS, _RHS):
    global scopes
    global charStream
    global charSegmentStream
    global quoting
    global segmentType
    global currentScope
    global sVars
    global keywords
    global methods
    _LHS.strip()
    _RHS.strip()
    if "`" in  _LHS:
        index = _LHS.split("`")
        sVars[VARS(index[0])][1 + int(float(varParser(index[1])))] = str(varParser(_LHS) / varParser(_RHS))
    if VARS(_LHS) is not False:
        sVars[VARS(_LHS)][1] = str(varParser(_LHS) / varParser(_RHS))


def prnt(_text):
    global scopes
    global charStream
    global charSegmentStream
    global quoting
    global segmentType
    global currentScope
    global sVars
    global keywords
    global methods
    #print(_text)
    textToPrint = ""
    for b in range(1, len(_text)):
        if "`" in  _text[b]:
            index = _text[b].split("`")
            if VARS(index[0]) is not False:
                #print(sVars[VARS(index[0])])
                textToPrint += sVars[VARS(index[0])][1 + int(float(varParser(index[1])))]
        elif VARS(_text[b]) is not False:
            textToPrint += sVars[VARS(_text[b])][1]
        elif VARS(_text[b]) is False:
            textToPrint += _text[b]
        
            
    print(textToPrint)
    return

def userInput(_text):
    global scopes
    global charStream
    global charSegmentStream
    global quoting
    global segmentType
    global currentScope
    global sVars
    global keywords
    global methods
    #print(_text)
    if "`" in _text[1]:
        index = _text[1].split("`")
        sVars[VARS(index[0])][1 + int(float(varParser(index[1])))] = input()
    else:
        sVars[VARS(_text[1])][1] = input()
    return

def openFile(_ARGS):
    global scopes
    global charStream
    global charSegmentStream
    global quoting
    global segmentType
    global currentScope
    global sVars
    global keywords
    global methods
    #print(_text)
    pastaFile = ""
    for b in range(2, len(_ARGS)):
        if "`" in _ARGS[b]:
            index = _ARGS[b].split("`")
            pastaFile += sVars[VARS(index[0])][1 + int(float(varParser(index[1])))]
        elif VARS(_ARGS[b]) is not False:
            pastaFile += sVars[VARS(_ARGS[b])][1]
        elif VARS(_ARGS[b]) is False:
            pastaFile += _ARGS[b]
        openedFiles.append(open(pastaFile))
    if "`" in _ARGS[1]:
        pindex = _ARGS[1].split("`")
        sVars[VARS(pindex[0])][1 + int(float(varParser(pindex[1])))] = openedFiles[len(openedFiles)-1].read()
        return
    else:
        sVars[VARS(_ARGS[1])][1] = openedFiles[len(openedFiles)-1].read()
        return


def conditional(_LHS, _TYPE, _RHS):
    global scopes
    global charStream
    global charSegmentStream
    global quoting
    global segmentType
    global currentScope
    global sVars
    global keywords
    global methods
    match _TYPE:
        case "is":
            if varParser(_LHS) == varParser(_RHS):
                return True
            elif varParser(_LHS) != varParser(_RHS):
                return False
        case "isn't":
            if varParser(_LHS) != varParser(_RHS):
                return True
            elif varParser(_LHS) == varParser(_RHS):
                return False
        case "more'n":
            if varParser(_LHS) > varParser(_RHS):
                return True
            elif varParser(_LHS) <= varParser(_RHS):
                return False
        case "less'n":
            if varParser(_LHS) < varParser(_RHS):
                return True
            elif varParser(_LHS) >= varParser(_RHS):
                return False
        case "equal'err":
            if varParser(_LHS) >= varParser(_RHS):
                return True
            elif varParser(_LHS) < varParser(_RHS):
                return False
        case "equal'ess":
            if varParser(_LHS) <= varParser(_RHS):
                return True
            elif varParser(_LHS) > varParser(_RHS):
                return False

#######INTERPRETER



def userFunction(_ARGS):
    #print("trigger")
    splitArgs = _ARGS[1].split(",")
    newArgs = [_ARGS[0]]
    newArgs.append(splitArgs)
    #print(_ARGS)
    executeUserFunction(newArgs)

#METHODS
methods = {
        "p": prnt,
        "review": userInput,
        "eat": openFile,
    }

def InstantiateFunction(_FUNCNAME):
    global scopes
    global charStream
    global charSegmentStream
    global quoting
    global segmentType
    global currentScope
    global sVars
    global keywords
    global methods
    #print(_FUNCNAME)
    methods[_FUNCNAME] = userFunction
    


#KEYWORDS
keyWords = {
        "noodle": newVar,
        "sauce": InstantiateFunction,
    }

#KEYWORD CONNECTION TO INTERPRETER
def parseKeyWord(_KEYWORD):
    global scopes
    global charStream
    global charSegmentStream
    global quoting
    global segmentType
    global currentScope
    global sVars
    global keywords
    global methods
    #print(_KEYWORD)
    kPARTS = _KEYWORD.split()
    keyWords[kPARTS[0]](_KEYWORD.split())

#METHOD CONNECTION TO INTERPRETER
def parseMethod(_METHOD):
    global scopes
    global charStream
    global charSegmentStream
    global quoting
    global segmentType
    global currentScope
    global sVars
    global keywords
    global methods
    #print(_KEYWORD)
    #print("method + " + _METHOD)
    mPARTS = _METHOD.split("~")
    #print(mPARTS)
    methods[mPARTS[0]](mPARTS)

#PARSE PARENT FUNCTION *****
def parse(_DATA):
    global scopes
    global charStream
    global charSegmentStream
    global quoting
    global segmentType
    global currentScope
    global sVars
    global keywords
    global methods
    #print(_DATA)
    for f in range(0, len(_DATA)):
        
        #print("f DATA : " + _DATA[f])
        if _DATA[f] == '~':
            #print(methods)
            parseMethod(_DATA)
            return
        elif _DATA[f].isspace():
            parseKeyWord(_DATA)
            return

scopeCounter = 0
scopesNumber = 0
lastEndLine = 0

def Interpret(rangeOne,rangeTwo, isFunction = "global"):
#streams
    global scopes
    global charStream
    global charSegmentStream
    global quoting
    global segmentType
    global currentScope
    global sVars
    global keywords
    global methods
    global scopeCounter
    global scopesNumber
    global lastEndLine
    lastLine = ""
    scopeCounter = 0
    scopesNumber = 0
    lastEndLine = 0
    #print(newentireFile)
    for c in range(rangeOne, rangeTwo):
        if c >= currentScope.start and c <= currentScope.end:
            if currentScope.canExecute == True:
                if newentireFile[c] == '"':
                    if quoting == True:
                        charSegmentStream += charStream
                        #print(charSegmentStream)
                    quoting = not quoting
                    if quoting == False:
                        charStream = ""
                elif quoting == False:
                    if newentireFile[c].isspace():
                        charStream += newentireFile[c]
                        charSegmentStream += charStream
                        if charSegmentStream == "sauce ":
                            newScope = scope(currentScope, "function", currentScope.start, currentScope.end)
                            scopes.append(newScope)
                            currentScope = newScope
                        charStream = ""
                    elif newentireFile[c] == "=":
                        segmentType = "set"
                        charStream += newentireFile[c]
                        charSegmentStream += charStream
                        charStream = ""
                    elif newentireFile[c] == "$":
                        segmentType = "subtract"
                        charStream += newentireFile[c]
                        charSegmentStream += charStream
                        charStream = ""
                    elif newentireFile[c] == "+":
                        segmentType = "add"
                        charStream += newentireFile[c]
                        charSegmentStream += charStream
                        charStream = ""
                    elif newentireFile[c] == "*":
                        segmentType = "multiply"
                        charStream += newentireFile[c]
                        charSegmentStream += charStream
                        charStream = ""
                    elif newentireFile[c] == "/":
                        segmentType = "divide"
                        charStream += newentireFile[c]
                        charSegmentStream += charStream
                        charStream = ""
                    elif newentireFile[c] == "^":
                        newScope = scope(currentScope, "condition", currentScope.start, currentScope.end)
                        scopes.append(newScope)
                        currentScope = newScope
                    elif newentireFile[c] == "?":
                        charSegmentStream += charStream
                        charStream = ""
                        if currentScope.statement != "global":
                            if currentScope.start == currentScope.parentScope.start:
                                currentScope.start = c
                                condition = charSegmentStream.split()
                                #print("FUNC NAME = " + currentScope.statement)
                                if isFunction == "global" and currentScope.statement == "function":
                                    #print("FUNC NAME = " + condition[1])
                                    InstantiateFunction(condition[1])
                                    currentScope.statement += " " + condition[1]
                                if currentScope.statement == "condition":
                                    #print(VARS())
                                    #print("CONDITION : " + condition[0] + " - " + condition[1] + " - " + condition[2])
                                    currentScope.canExecute = conditional(condition[0],condition[1],condition[2])
                                    #print("CONDITION MET : " + str(currentScope.canExecute))
                                    if currentScope.canExecute == False:
                                        scopesNumber = 0
                                elif currentScope.statement == "function " + condition[1]:
                                    if isFunction == "global":
                                        currentScope.canExecute = False
                                        scopesNumber = 0
                            elif currentScope.start != currentScope.parentScope.start:
                                if "function" not in currentScope.statement:
                                    currentScope.end = c
                                    currentScope = currentScope.parentScope
                        else:
                            newScope = scope(currentScope, "main", currentScope.start, currentScope.end)
                            scopes.append(newScope)
                            currentScope = newScope
                            if currentScope.start == currentScope.parentScope.start:
                                currentScope.start = c
                            elif currentScope.start != currentScope.parentScope.start:
                                if "function" not in currentScope.statement:
                                    currentScope.end = c
                                    currentScope = currentScope.parentScope
                        charSegmentStream = ""
                    elif newentireFile[c] == "|":
                        lastEndLine = c
                        #print(charSegmentStream)
                        if segmentType == "set":
                            #charSegmentStream += charStream
                            LRSIDE = charSegmentStream
                            LRSIDE = LRSIDE.split("=")
                            LRSIDE[0] = LRSIDE[0].strip(" ")
                            LRSIDE[1] = LRSIDE[1].strip(" ")
                            #print(LRSIDE)
                            equalSet(LRSIDE[0], LRSIDE[1])
                        elif segmentType == "subtract":
                            #charSegmentStream += charStream
                            LRSIDE = charSegmentStream
                            LRSIDE = LRSIDE.split("$")
                            LRSIDE[0] = LRSIDE[0].strip(" ")
                            LRSIDE[1] = LRSIDE[1].strip(" ")
                            #print(LRSIDE)
                            subtractSet(LRSIDE[0], LRSIDE[1])
                        elif segmentType == "add":
                            #charSegmentStream += charStream
                            LRSIDE = charSegmentStream
                            LRSIDE = LRSIDE.split("+")
                            LRSIDE[0] = LRSIDE[0].strip(" ")
                            LRSIDE[1] = LRSIDE[1].strip(" ")
                            #print(LRSIDE)
                            addSet(LRSIDE[0], LRSIDE[1])
                        elif segmentType == "multiply":
                            #charSegmentStream += charStream
                            LRSIDE = charSegmentStream
                            LRSIDE = LRSIDE.split("*")
                            LRSIDE[0] = LRSIDE[0].strip(" ")
                            LRSIDE[1] = LRSIDE[1].strip(" ")
                            #print(LRSIDE)
                            multiplySet(LRSIDE[0], LRSIDE[1])
                        elif segmentType == "divide":
                            #charSegmentStream += charStream
                            LRSIDE = charSegmentStream
                            LRSIDE = LRSIDE.split("/")
                            LRSIDE[0] = LRSIDE[0].strip(" ")
                            LRSIDE[1] = LRSIDE[1].strip(" ")
                            #print(LRSIDE)
                            divideSet(LRSIDE[0], LRSIDE[1])
                        elif segmentType == "":
                            #print("PARSE : " + " (CHAR STREAM) > " + charStream + " (SEG STREAM) > " +charSegmentStream)
                            parse(charSegmentStream)
                        charSegmentStream = ""
                        charStream = ""
                        segmentType = ""
                        quoting = False
                    else:
                        charStream += newentireFile[c]
                        charSegmentStream += charStream
                        charStream = ""
                else:#QUOTING
                    charStream += newentireFile[c]
            else:
                if newentireFile[c] == '"':
                    if quoting == True:
                        charSegmentStream += charStream
                        #print(charSegmentStream)
                    quoting = not quoting
                    if quoting == False:
                        charStream = ""
                elif quoting == False:
                    if newentireFile[c] == "^":
                        lastLine = "^"
                        scopeCounter = 0
                        scopesNumber += 1
                    elif newentireFile[c] == "?":
                        if lastLine == "^":
                            scopeCounter += 1
                            if scopeCounter == 2:
                                lastLine = ""
                                scopesNumber -= 1
                        elif scopesNumber >= 1:
                            scopesNumber -= 1
                        elif scopesNumber == 0:
                            currentScope.end = c
                            #print(str(currentScope.statement) + " s : " + str(currentScope.start) + " e : " + str(currentScope.end))
                            currentScope = currentScope.parentScope





def executeUserFunction(_FUNCARGS):
    global scopes
    global charStream
    global charSegmentStream
    global quoting
    global segmentType
    global currentScope
    global sVars
    global keywords
    global methods
    global scopeCounter
    global scopesNumber
    global lastEndLine
    correctScope = ""
    #for i in range(0,len(_FUNCARGS)-1):
        #newVar(_FUNCARGS[i])
    for i in range(0, len(scopes)-1):
        funcParts = scopes[i].statement.split()
        #print("SCOPE STATEMENT = " + funcParts[1])
        #print("FUNC ARGS = " + _FUNCARGS[0])
        if funcParts[1] == _FUNCARGS[0]:
            correctScope = scopes[i]
            break
    currentScope = correctScope
    currentScope.canExecute = True
    #print(currentScope.start)
    #print(currentScope.end)
    charSegmentStream = ""
    charStream = ""
    segmentType = ""
    scopeCounter = 0
    scopesNumber = 0
    Interpret(currentScope.start, currentScope.end, "function")
    currentScope = currentScope.parentScope
    #for i in range(0,len(_FUNCARGS)-1):
        #delVar(_FUNCARGS[i])


##FILE LOOP
Interpret( currentScope.start, currentScope.end)
#print(methods)
#print(VARS())
for i in range(0,len(openedFiles)-1):
    openedFiles[i].close()

file.close()