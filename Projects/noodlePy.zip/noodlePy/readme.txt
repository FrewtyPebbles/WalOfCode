--------------------------------------------------------
 noodlePy is a scripting language written by William L.
--------------------------------------------------------

The documentation for noodlePy can be found at:

 https://www.walofcode.com/

Anything you write in this language is legally owned by the omnipotent flying spaghetti monster that watches
over all of existance. Sorry, I dont make the rules.