sVars = []

def VARS(_VARNAME = "all"):
    if _VARNAME == "all":
        return sVars
    else:
        #code
        for i in range(len(sVars)):
            if sVars[i][0] == _VARNAME:
                return i
        return False
def newVar(_VAR):
    return sVars.append([_VAR[1] , _VAR[2]])

def equalSet(_LHS, _RHS):
    _LHS.strip()
    _RHS.strip()
    if VARS(_LHS) is not False:
        if VARS(_RHS) is not False:
            sVars[VARS(_LHS)][1] = sVars[VARS(_RHS)][1]
            return
        else:
            sVars[VARS(_LHS)][1] = _RHS
            return

def prnt(_text):
    if VARS(_text[1]) is not False:
        print(sVars[VARS(_text[1])][1])
        return
    else:
        print(_text[1])
        return


#KEYWORDS
keyWords = {
        "noodle": newVar,
    }
#METHODS
methods = {
        "p": prnt,
    }

#KEYWORD CONNECTION TO INTERPRETER
def parseKeyWord(_KEYWORD):
    #print(_KEYWORD)
    kPARTS = _KEYWORD.split()
    keyWords[kPARTS[0]](_KEYWORD.split())

#METHOD CONNECTION TO INTERPRETER
def parseMethod(_METHOD):
    #print(_KEYWORD)
    mPARTS = _METHOD.split(":")
    methods[mPARTS[0]](_METHOD.split(":"))

#PARSE PARENT FUNCTION *****
def parse(_DATA):
    for c in range(0, len(_DATA)):
        #print("C DATA : " + _DATA[c])
        if _DATA[c] == ':':
            parseMethod(_DATA)
            break
        elif _DATA[c].isspace():
            parseKeyWord(_DATA)
            break

def conditional(_LHS, _TYPE, _RHS):
    if _TYPE == "is":
        if sVars[VARS(_LHS)][1] == sVars[VARS(_RHS)][1]:
            return True
        elif sVars[VARS(_LHS)][1] != sVars[VARS(_RHS)][1]:
            return False
    elif _TYPE == "isn't":
        if sVars[VARS(_LHS)][1] != sVars[VARS(_RHS)][1]:
            return True
        elif sVars[VARS(_LHS)][1] == sVars[VARS(_RHS)][1]:
            return False